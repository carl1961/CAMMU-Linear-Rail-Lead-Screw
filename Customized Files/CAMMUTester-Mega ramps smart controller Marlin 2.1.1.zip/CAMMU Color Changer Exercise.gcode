; ********************************************
; CAMMU FILAMENT Change Exercise V1 10/3/2025
; ********************************************
; AS IT WORK
; - load this file on SD card and print it as a normal gcode file
; - Make sure all filament is loaded past extruter gears ready to load.
; - change the nozzle expulsion and bleed length according to your needs
;

M117 FILAMENT Exercise; LCD message
G90 ; use absolute positioning

G92 E0 ; Reset extruder length to zero
G21 ; unit of measure in mm
G28 x ; homing x axes


; #####################################
;    AUTOMATIC FILAMENT EXERCISE
; #####################################

M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T1
G90 ; use absolute positioning
G1 X11 F300 ;
   M400 ; wait for the previous function to complete
M117 Filament T1 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero

M117 Filament T1 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero



M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause


M117 Moving to T2
G90 ; use absolute positioning
G1 X33 F300 ;
   M400 ; wait for the previous function to complete

M117 Filament T2 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T2 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero



M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T3
G90 ; use absolute positioning

G1 X55 F300 ;
   M400 ; wait for the previous function to complete
   
M117 Filament T3 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T3 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero


M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T4
G90 ; use absolute positioning

G1 X77 F300 ;
   M400 ; wait for the previous function to complete
   
M117 Filament T4 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T4 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero



M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T5
G90 ; use absolute positioning

G1 X99 F300 ;
   M400 ; wait for the previous function to complete

M117 Filament T5 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T5 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero



M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T6
G90 ; use absolute positioning

G1 X122 F300 ;
   M400 ; wait for the previous function to complete

M117 Filament T6 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T6 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero


M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T7
G90 ; use absolute positioning
G1 X145 F300 ;
   M400 ; wait for the previous function to complete

M117 Filament T7 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T7 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero


M300 S400 P500; acoustic warning Hz and ms
G4 P500 ; pause
M300 S400 P250; acoustic warning Hz and ms
G4 P500 ; pause

M117 Moving to T8
G90 ; use absolute positioning
G1 X165 F300 ;
   M400 ; wait for the previous function to complete

M117 Filament T8 Loading
G92 E0 ; Reset extruder length to zero
G1 E50 F500 ; indicates the mm to be extruded before the expulsion of the filament F the speed in mm / m
   M400 ; wait for the previous function to complete 
G92 E0 ; Reset extruder length to zero

M117 Filament T8 UnLoading
G1 E-50 F500 ; quantity of filament to eject in mm 
    M400 ; wait for the previous function to complete
G92 E0 ; Reset extruder length to zero
G91 ; sets the coordinates relatively

M117 Exercise Done!



; #####################################
M0 ; waits for the key to be pressed at the end
; #####################################



M300 S400 P300 ; acoustic warning
G4 P500 ; pause
M300 S400 P300 ; acoustic warning
G4 P500 ; pause
M300 S400 P1000 ; acoustic warning
G4 P1200 ; pause

; Enjoy the easy change!